import json,pathlib,html
r=pathlib.Path('/workspace/rea-analysis/tooth'); forms=json.loads((r/'forms.json').read_text())
report='''# تحليل Tooth.exe لإعادة بنائه كتطبيق ويب

تم الفحص الساكن داخل Linux Cloud دون تشغيل الملف أو تنفيذ تعليماته. استخدمت REA لفحص الأثر وGNU objdump للرأس، وpefile لاستخراج الموارد، وقارئاً لتعريفات Delphi DFM.

## الهوية المثبتة
- الحجم: 2,601,984 بايت، Windows PE32 x86، تطبيق رسومي أصلي وليس .NET (حجم CLI header يساوي صفر).
- SHA-256: `82e994b8f5a0e3be9cc4cae5ba40341dc1a8f8b55e1a27e2d8c28f82706e0068`.
- Delphi / VCL: موارد TPF0، عناصر TPaintBox/TPanel/TAction، ومسارات Embarcadero RAD Studio 10.0 داخل الملف. المسارات قرينة على سلسلة أدوات البناء وليست إثباتاً وحيداً لإصدار المترجم.
- شاشة About: Tooth، version 1.2، Orthodontic Tooth Simulator، Copyright © D.Halazonetis 1996-2024، Kifissia, Greece.
- بيانات إصدار Windows: FileVersion 1.2.1.0، ProductVersion 1.0.0.0؛ اختلافها عن About محفوظ كما هو.

## الشاشات الخمس المستخرجة
1. MainForm: مساحة رسم 2D بأحداث رسم وماوس، شريط أدوات وقوائم File/Edit/View/Ortho/Help، فتح وحفظ وطباعة، تكبير واختيار وتحريك ودوران، تشغيل/إيقاف، تراجع/إعادة، ونقطة مرجعية.
2. Tooth Info: تبويبا Tooth وPerio؛ طول الجذر التشريحي والوظيفي ومساحته، Angulation، dx/dy، Ankylosed، رسم استجابة الأنسجة ونتائج Force X/Y وMoment.
3. Wire: الطول، Force، Moment A/B، Angle Ratio، Burstone Class، اختيار مادة السلك ومقاسه.
4. Loop Options: General/View/Calculation؛ القوى والعزوم، أسنان أو أسلاك، شبكة 10/5/2 mm، Snap، مواضع رسم القوى، Auto Stop وحدود Force (gf) وMoment (gf.mm)، قيمتا الحد في تعريف الشاشة 1 و1.
5. About Tooth: التعريف والنسخة والمؤلف.

القوائم تعرض أرقام أسنان إضافية، لكن أصناف الأسنان الخاصة المستخرجة تؤكد 33،34،35،36،43،44،45،46 فقط. لا يمكن اعتبار كل رقم معروض في القائمة ميزة منفذة؛ بعض العناصر بلا معالج OnClick في تعريف الشاشة وقد توجد توصيلات وقت التشغيل لم نفحصها.

## النموذج الداخلي المستدل عليه من بيانات الأنواع
- TTooth: هندسة التاج والجذر، مركز المقاومة، Brackets، Ankylosed، rootLengthFunctional، rootAreaFunctional، stressTranslation، stressRotation؛ دوال Translate/Rotate/OrthoMove/SetAsOriginalPosition/ResetToOriginalPosition.
- TWireStraight: مادة ومقاس ونقطتا اتصال، MomentInertia، ModulusElasticity، Length، Force، MomentA/B، AngleRatio، BurstoneClass.
- TBracket/TAttachment: موضع وزاوية وارتباط بالسن والأسلاك.
- TForceMoment/TForceMomentV: تمثيل القوى والعزوم وتحويلها، بما فيه MomentAtPoint.
هذه أسماء وارتباطات مستخرجة، وليست برهاناً على معادلاتها أو دقة قيمها.

## ما يلزم لنسخة HTML
البرنامج يحتاج HTML وCSS للواجهات، وJavaScript للحالة والتفاعل والحسابات، وSVG أو Canvas للرسم. العرض الأصلي يعتمد على رسم برمجي في TPaintBox؛ لذلك استخراج النوافذ وحده لا يستعيد أشكال الأسنان المرسومة أو سلوك محرك الفيزياء.

البناء المقترح: نموذج Tooth/Wire/Bracket مستقل، طبقة رسم SVG ثنائية الأبعاد بوحدات mm، أدوات اختيار/تحريك/دوران وتكبير وشبكة، نوافذ خصائص، تاريخ undo/redo ومرجع initial state، حفظ JSON واستيراده وتصدير SVG/PNG وطباعة. محرك القوى وحركة الأسنان وحدة منفصلة مع اختبارات مرجعية قبل عرض نتائج كمية على أنها مطابقة.

الفتح والحفظ في الأصل يستخدمان مرشح Tooth files (*.txt). هذا يثبت الامتداد المقصود، ولا يثبت تنسيق البيانات؛ يلزم ملف حالة محفوظ من البرنامج لتحليل التوافق.

## حدود الفحص الحالي
- لم يتم تشغيل البرنامج أو تصوير شاشاته الفعلية؛ المعاينة المرفقة إعادة عرض لتعريفات التصميم المخزنة.
- لم تثبت المعادلات، ثوابت المواد، هندسة الأسنان، نموذج استجابة الأنسجة، قانون الحركة مع الزمن أو تصنيف Burstone المستخدم.
- Ghidra غير مثبت. يمكن إجراء فحص أعمق بـ Ghidra ومحرك Java المتوافق داخل Linux Cloud إذا احتجنا استعادة الحسابات؛ لا يلزم Mac لهذا الفحص. معايرة السلوك أمام البرنامج الأصلي تتطلب بيئة تنفيذ Windows مناسبة منفصلة، وليست متاحة ضمن هذا الفحص.
- لا يوجد تحويل تلقائي موثوق من EXE إلى HTML. بناء الواجهة ممكن؛ المطابقة الحسابية تحتاج أدلة إضافية.
- لم يكن هذا فحصاً أمنياً شاملاً، وعدم تشغيل الملف لا يثبت سلامته.

## المخرجات
`tooth-analysis.html`: تقرير عربي ومعاينة تفاعلية للواجهات والخصائص؛ اختيارات العرض والتبويبات تعمل، أما أزرار البرنامج الأصلية فغير مفعلة.
`forms.json`: جميع النماذج المحللة، شجرة العناصر، المواقع، النصوص، أسماء الأحداث. القيم الثنائية الكبيرة موصوفة بحجمها وبادئتها فقط؛ الموارد الخام محفوظة منفصلة في مجلد التحليل.
`artifact.json` و`headers.json`: أدلة REA مع بصمة الملف ونتائج الفحص.

لزيادة دقة إعادة البناء: ملفات TXT المحفوظة والأمثلة قبل/بعد الحركة ولقطات الشاشات من المصدر إن كانت متاحة تساعد على استعادة الرسم والتحقق من الحسابات. لا تعتمد الحسابات المعاد بناؤها في قرارات علاجية قبل التحقق من صحتها.
'''
(r/'deliverables/analysis-ar.md').write_text(report)
css='''*{box-sizing:border-box}body{margin:0;background:#f3f6fa;color:#213044;font:16px system-ui;line-height:1.8}header{background:#112a41;color:white;padding:30px max(24px,6vw)}main{max-width:1160px;margin:auto;padding:24px}h1{margin:0}h2{font-size:22px}section{background:white;border:1px solid #dae3ed;border-radius:14px;padding:24px;margin:18px 0}button,select{font:inherit;padding:8px 14px;border:1px solid #b9c9da;border-radius:7px;background:white;color:#163b60}button[aria-selected=true]{background:#155e75;color:white}#selectors{display:flex;flex-wrap:wrap;gap:10px}.preview{direction:ltr;overflow:auto;padding:22px;background:#e9eef4;border-radius:10px}.window{background:#f0f0f0;position:relative;box-shadow:0 5px 20px #0002;font:11px Tahoma,Arial;color:black;border:1px solid #8397ab}.title{background:#e1eaf4;padding:4px;font-weight:bold}.node{position:absolute;font:inherit;overflow:hidden}.panel{border:1px solid #aaa}.paint{background:white;border:1px dashed #8b9cad;display:flex;align-items:center;justify-content:center;color:#718295;text-align:center}.label{white-space:nowrap}button.node{padding:0;border-radius:2px;background:#eee;border:1px solid #aaa;color:#555;font:inherit}input.node,select.node{padding:1px;border:1px solid #aaa;border-radius:0;font:inherit}.tabs{display:flex;gap:2px;height:24px}.tabs button{font:11px Tahoma;padding:2px 8px;border-radius:0}.tabbody{position:relative}.menubar{padding:3px 8px;border-bottom:1px solid #bbb;word-spacing:14px}.tools{position:absolute;left:4px;top:3px;display:flex;gap:4px}.tools span{border:1px solid #bbb;background:#f8f8f8;padding:2px 6px}.hint{background:#fff6df;padding:12px;border-radius:8px}pre{direction:ltr;text-align:left;white-space:pre-wrap;font-size:12px;background:#f5f7fa;padding:14px;max-height:420px;overflow:auto}article{white-space:pre-wrap}footer{color:#607086;font-size:13px}#meta{max-height:250px;overflow:auto}'''
page='''<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>تحليل Tooth — واجهات البرنامج</title><style>CSS</style><header><h1>Tooth · تحليل وإعادة بناء الواجهات</h1><p>Orthodontic Tooth Simulator — فحص ساكن داخل Linux Cloud</p></header><main><section><h2>معاينة عناصر الواجهة المستخرجة</h2><p class="hint">هذه معاينة لتعريفات Delphi المخزنة، وليست لقطة للبرنامج أثناء التشغيل أو محاكاة لحركة الأسنان. أزرار البرنامج غير مفعلة؛ يمكنك تغيير الشاشة والتبويبات ومراجعة خصائصها.</p><div id="selectors"></div><p id="caption"></p><div class="preview"><div id="mount"></div></div><details><summary>خصائص النموذج والأحداث الأصلية</summary><pre id="meta"></pre></details></section><section><h2>نتائج الفحص وخطة نسخة HTML</h2><article>REPORT</article></section><footer>لم يُشغَّل Tooth.exe. لا توجد اتصالات خارجية أو مكتبات CDN في هذا الملف.</footer></main><script id="forms" type="application/json">DATA</script><script>
const forms=JSON.parse(document.querySelector('#forms').textContent), mount=document.querySelector('#mount');
const cap=x=>String(x??'').replaceAll('&','');
const ignored=new Set(['TMainMenu','TMenuItem','TActionList','TAction','TImageList','TSaveDialog','TOpenDialog']);
function node(o,parent){if(ignored.has(o.class))return;const p=o.properties,c=o.class;let e=document.createElement('div');e.className='node';
if(c==='TTabSheet')return;
if(c==='TButton'||c==='TSpeedButton'||c==='TToolButton'){e=document.createElement('button');e.className='node';e.disabled=true;e.textContent=cap(p.Caption||o.name);}
else if(c==='TLabel'){e.classList.add('label');e.textContent=cap(p.Caption);}
else if(c==='TEdit'){e=document.createElement('input');e.className='node';e.value=p.Text||'';e.disabled=true;}
else if(c==='TComboBox'){e=document.createElement('select');e.className='node';for(const s of p['Items.Strings']||[p.Text||'—']){const opt=document.createElement('option');opt.textContent=s;e.append(opt);}e.disabled=true;}
else if(c==='TCheckBox'){e.textContent=(p.Checked?'☑ ':'☐ ')+cap(p.Caption);}
else if(c==='TPaintBox'){e.classList.add('paint');e.textContent='Custom drawing · not recovered';}
else if(c==='TPanel'||c==='TGroupBox'||c==='TRadioGroup'){e.classList.add('panel');if(p.Caption)e.textContent=cap(p.Caption);if(p['Items.Strings'])e.textContent+=' '+p['Items.Strings'].join(' ○ ');}
else if(c==='TScrollBar'){e.style.background='#ddd';}
else if(c==='TImage'){e.classList.add('paint');e.textContent='Image';}
else if(c==='TToolBar'){return;}
e.title=o.class+' '+o.name+(p.Hint?' — '+p.Hint:'');e.style.left=(p.Left||0)+'px';e.style.top=(p.Top||0)+'px';e.style.width=(p.Width||100)+'px';e.style.height=(p.Height||20)+'px';parent.append(e);
if(c==='TPageControl'){const tabs=document.createElement('div');tabs.className='tabs';e.append(tabs);const body=document.createElement('div');body.className='tabbody';e.append(body);const children=o.children.filter(x=>x.class==='TTabSheet');function show(t){body.replaceChildren();for(const b of tabs.children)b.setAttribute('aria-selected',b.dataset.name===t.name);for(const ch of t.children)node(ch,body);}for(const t of children){const b=document.createElement('button');b.textContent=cap(t.properties.Caption);b.dataset.name=t.name;b.onclick=()=>show(t);tabs.append(b);}if(children.length)show(children.find(t=>t.name===p.ActivePage)||children[0]);return;}
for(const ch of o.children)node(ch,e);
if(o.name==='ControlBarTools'){const t=document.createElement('div');t.className='tools';t.innerHTML='<span>New</span><span>Open</span><span>Save</span><span>Print</span><span>Run</span><span>Stop</span><span>Undo</span><span>Redo</span><span>Zoom</span><span>Move / Rotate</span>';e.append(t);}
}
function show(key){mount.replaceChildren();const o=forms[key],p=o.properties;for(const b of document.querySelector('#selectors').children)b.setAttribute('aria-selected',b.dataset.key===key);document.querySelector('#caption').textContent=cap(p.Caption)+' — '+p.ClientWidth+' × '+p.ClientHeight+' design pixels';document.querySelector('#meta').textContent=JSON.stringify(o,null,2);const w=document.createElement('div');w.className='window';w.style.width=(p.ClientWidth+2)+'px';mount.append(w);const title=document.createElement('div');title.className='title';title.textContent=cap(p.Caption);w.append(title);if(key==='TMAINFORM'){const menu=document.createElement('div');menu.className='menubar';menu.textContent='File Edit View Ortho Help';w.append(menu);}const body=document.createElement('div');body.style.position='relative';body.style.height=p.ClientHeight+'px';w.append(body);for(const ch of o.children)node(ch,body);}
for(const [key,o] of Object.entries(forms)){const b=document.createElement('button');b.textContent=cap(o.properties.Caption);b.dataset.key=key;b.onclick=()=>show(key);document.querySelector('#selectors').append(b);}show('TMAINFORM');
</script></html>'''
page=page.replace('CSS',css).replace('REPORT',html.escape(report)).replace('DATA',json.dumps(forms,ensure_ascii=False).replace('<','\\u003c'))
(r/'deliverables/tooth-analysis.html').write_text(page)
for n in ['forms.json','artifact.json','headers.json','pe-summary.json','forms-summary.txt']:(r/'deliverables'/n).write_bytes((r/n).read_bytes())
