import struct,json,pathlib
class Reader:
 def __init__(self,b):self.b=b;self.p=4
 def read(self,n):v=self.b[self.p:self.p+n];assert len(v)==n;self.p+=n;return v
 def num(self,f):return struct.unpack('<'+f,self.read(struct.calcsize('<'+f)))[0]
 def string(self):return self.read(self.num('B')).decode('cp1252',errors='replace')
 def val(self,t=None):
  t=self.num('B') if t is None else t
  if t in (0,13):return None
  if t==1:
   a=[]
   while self.b[self.p]:a.append(self.val())
   self.p+=1;return a
  if t in (2,3,4,19):return self.num({2:'b',3:'h',4:'i',19:'q'}[t])
  if t==5:return {'extended_hex':self.read(10).hex()}
  if t in (6,7):return self.string()
  if t in (8,9):return t==9
  if t==10:
   n=self.num('I');v=self.read(n);return {'binary_size':n,'prefix':v[:20].hex()}
  if t==11:
   a=[]
   while self.b[self.p]:a.append(self.string())
   self.p+=1;return a
  if t in (12,20):return self.read(self.num('I')).decode('utf-8' if t==20 else 'cp1252',errors='replace')
  if t==14:
   a=[]
   while self.b[self.p]:
    mark=self.num('B');assert mark==1,(self.p,mark)
    a.append(self.props())
   self.p+=1;return a
  if t in (15,16,17):return self.num({15:'f',16:'q',17:'d'}[t])
  if t==18:return self.read(self.num('I')*2).decode('utf-16le',errors='replace')
  raise ValueError((self.p,t))
 def props(self):
  d={}
  while self.b[self.p]:
   k=self.string();d[k]=self.val()
  self.p+=1;return d
 def obj(self):
  flags=0
  if self.b[self.p]&0xf0==0xf0:
   flags=self.num('B')&15
   if flags&2:self.val()
  d={'class':self.string(),'name':self.string(),'properties':self.props(),'children':[]}
  while self.b[self.p]:d['children'].append(self.obj())
  self.p+=1;return d
root=pathlib.Path('/workspace/rea-analysis/tooth'); forms={}
def walk(o,depth=0):
 p=o['properties'];summary={k:v for k,v in p.items() if k in ('Caption','Hint','Text','Items.Strings','ClientWidth','ClientHeight') or k.startswith('On')};print(' '*depth+o['class']+' '+o['name']+' '+json.dumps(summary,ensure_ascii=False))
 for c in o['children']:walk(c,depth+1)
for p in sorted((root/'resources/10').glob('*.bin')):
 if p.read_bytes().startswith(b'TPF0'):
  print('\nFORM',p.stem)
  try:
   r=Reader(p.read_bytes());o=r.obj();assert r.p==len(r.b),(r.p,len(r.b));forms[p.stem]=o;walk(o)
  except Exception as e:print('PARSE FAILED',repr(e));raise
(root/'forms.json').write_text(json.dumps(forms,ensure_ascii=False,indent=2))
