import sys,json,pathlib,hashlib
sys.path.insert(0,'/workspace/rea-analysis/python-libs')
import pefile
root=pathlib.Path('/workspace/rea-analysis/tooth'); pe=pefile.PE('/workspace/attachments/c45dc6d5-340a-482a-9e4c-d9c4efdce460/Tooth.exe')
out=[]
for t in pe.DIRECTORY_ENTRY_RESOURCE.entries:
 for n in t.directory.entries:
  for l in n.directory.entries:
   d=l.data.struct; b=pe.get_data(d.OffsetToData,d.Size); name=str(n.name or n.id); path=root/'resources'/str(t.name or t.id)/(name+'.bin');path.parent.mkdir(exist_ok=True,parents=True);path.write_bytes(b);out.append({'type':str(t.name or t.id),'name':name,'size':len(b),'path':str(path),'dfm':b.startswith(b'TPF0')})
info={'machine':hex(pe.FILE_HEADER.Machine),'cli_header_size':pe.OPTIONAL_HEADER.DATA_DIRECTORY[14].Size,'imports':[x.dll.decode() for x in pe.DIRECTORY_ENTRY_IMPORT],'resources':out}
(root/'pe-summary.json').write_text(json.dumps(info,indent=2))
print(json.dumps(info,indent=2))
