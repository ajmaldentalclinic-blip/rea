import { chromium } from '/workspace/rea-tools/lib/node_modules/rea-agents/node_modules/playwright-core/index.mjs';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
try {
 const page=await browser.newPage({viewport:{width:1280,height:900}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.setContent(await readFile('/workspace/rea-analysis/tooth/deliverables/tooth-analysis.html','utf8')); 
 assert.equal(await page.locator('#selectors button').count(),5);
 for (let i=0;i<5;i++){await page.locator('#selectors button').nth(i).click();assert.equal(await page.locator('.window').count(),1);assert((await page.locator('#meta').textContent()).length>100);}
 await page.locator('#selectors button').filter({hasText:'Tooth Info'}).click();await page.locator('.tabs button').filter({hasText:'Perio',exact:true}).click();assert(await page.locator('.tabbody').textContent().then(t=>t.includes('Pre-defined Responses')));
 await page.locator('#selectors button').filter({hasText:'Tooth [Untitled]',exact:true}).click();
 await page.screenshot({path:'/workspace/rea-analysis/tooth/deliverables/preview.png',fullPage:false});assert.deepEqual(errors,[]);console.log('PASS: 5 forms rendered; Perio tab switches; no JavaScript errors.');
} finally {await browser.close();}
